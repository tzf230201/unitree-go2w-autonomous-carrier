Basics
======

Return codes
------------

.. doxygengroup:: retcode
    :project: ddsc_api_docs
    :members:
