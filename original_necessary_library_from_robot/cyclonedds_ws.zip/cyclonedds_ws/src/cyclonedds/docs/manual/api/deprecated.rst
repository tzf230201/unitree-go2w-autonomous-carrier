Deprecated functionality
========================

All functionality in this section is considered deprecated. They will generate warnings and could be removed in a major release.

.. doxygengroup:: deprecated
    :project: ddsc_api_docs
    :members:

